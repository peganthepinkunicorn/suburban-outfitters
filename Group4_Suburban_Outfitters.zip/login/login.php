<HTML>
<title>Login</title>
<head>
	<link rel='stylesheet' href='../styles.css'>
</head>

<body>
	<div class='page-content'>
		<div class="login-container bg-grey">
			<img src='../images/logo.png' class='logo-round'></img>
			<h3>Suburban</h3>
			<h3>Outfitters</h3>
			<h1>Login</h1>
			<form method='POST' action='../home/home.php'>
				Username: <br>
				<input type='text' name='username'><br><br>
				Password: <br>
				<input  type='password' name='password'><br><br>
				<div class="login-buttons">
				<input type='image' name='login' src='../images/log-in-button.png'/>
				</div>
			</form>
			<a href='../account/account.php'><img src='../images/signup-button.png'></img></a>
		</div>
	</div>
</body>
</HTML>

<!--Add New User signup-->